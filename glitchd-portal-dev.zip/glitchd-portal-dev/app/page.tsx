import { Fragment } from 'react';
import { FooterSection } from '@/components/FooterSection';
import { FutureTech } from '@/components/FutureTech';
import MainHeroPage from '@/components/Hero/main-hero';
import { Solution } from '@/components/Solution/solution';
import { TechnicalAdvantages } from '@/components/TechAdvantages/technical-advantages';
import { Roadmap } from '@/components/roadmap/roadmap';
import { LatestNews } from '@/components/latestNews/latestNews';
import { DemoExpertise } from '@/components/expertise/demo-experitse';
import { Expertise } from '@/components/expertise';

export default function Home() {
	return (
		<Fragment>
			<MainHeroPage />
			<div className='web-view--expertise'>
				<DemoExpertise />
			</div>
			<div className='mobile-view--expertise'>
				<Expertise />
			</div>
			<FutureTech />
			<TechnicalAdvantages />
			<Solution />
			<Roadmap />
			<LatestNews />
			<FooterSection />
		</Fragment>
	);
}
