'use client';

import { useEffect } from 'react';

export default function Template({ children }: { children: React.ReactNode }) {
	useEffect(() => {
		if (typeof window !== 'undefined') {
			window.scrollTo({ top: 0, behavior: 'smooth' });
			document.body.style.overflow = 'hidden';
		}
	}, []);

	return <>{children}</>;
}
