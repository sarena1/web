'use client';

import { MutableRefObject, useEffect } from 'react';

export default function Observer({
	children,
	sectionRef,
	callBack
}: {
	children: React.ReactNode;
	sectionRef: MutableRefObject<null>;
	callBack: () => void;
}) {
	useEffect(() => {
		const observer = new IntersectionObserver(
			(entries) => {
				entries.forEach((entry) => {
					if (entry.isIntersecting && entry.intersectionRatio === 1) {
						callBack();
					}
				});
			},
			{
				root: null, // Use the viewport as the root
				threshold: 1.0 // Trigger only when the section is fully in view
			}
		);

		if (sectionRef.current) {
			observer.observe(sectionRef.current);
		}

		return () => {
			if (sectionRef.current) {
				observer.unobserve(sectionRef.current);
			}
		};
	}, [sectionRef, callBack]);
	return <>{children}</>;
}
