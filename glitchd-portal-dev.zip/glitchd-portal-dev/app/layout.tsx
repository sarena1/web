import '../public/styles/app.scss';
import { Metadata } from 'next';

export const metadata: Metadata = {
	title: 'GlitchD',
	description: 'Superior ZK-EVM technology solving real-world problems'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
	return (
		<html lang='en'>
			<body>
				<main className='container'>{children}</main>
			</body>
		</html>
	);
}
