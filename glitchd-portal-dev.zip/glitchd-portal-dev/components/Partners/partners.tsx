import { FC } from 'react';
import './partners.scss';
import Transition from '@/app/animations';

interface IProps {
	currentAnimation: number;
}

export const Partners: FC<IProps> = ({ currentAnimation }) => {
	return (
		<section className={`partners flex layer${currentAnimation <= 3 ? '1' : '2'}`}>
			<div className='content item-wrapper flex justify-content--between align-items--end'>
				<div className='title-wrapper'>
					<p className='font-size--14 flex align-items--center'>
						<span className='square mr--10' />
						Trusted by
					</p>
					<h1 className='section-title  font--bold'>
						Our <span className='gradient-text'>Strategic</span> Partners
					</h1>
				</div>
			</div>
			<div className='logo-wrapper partner-wrapper__first item-wrapper flex flex--column justify-content--between align-items--end'>
				<img className='logo' src='/images/partner-layer-1-logo.png' alt='logo' />
				<p className='desc font-size--32 font--bold'>Immersive In-Game Ads & Product Placement</p>
			</div>
			{currentAnimation > 3 && (
				<div className='logo-wrapper partner-wrapper__second item-wrapper flex flex--column justify-content--between align-items--end'>
					<img className='logo' src='/images/partner-layer-2-logo.png' alt='logo' />
					<p className='desc font-size--32 font--bold'>
						{' '}
						Layer 1 Blockchain with zero gas transactions and enhanced security
					</p>
				</div>
			)}
		</section>
	);
};
