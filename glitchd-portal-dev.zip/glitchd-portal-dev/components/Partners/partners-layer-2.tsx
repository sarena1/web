import './partners.scss';

export const PartnersLayer2 = () => {
	return (
		<section className='partners layer2'>
			<div className='logo-wrapper width--full flex justify-content--end'>
				<div className='logo layer1  flex justify-content--end'>
					<img src='/images/partner-layer-1-logo.png' alt='logo' />
				</div>
				<div className='logo layer1  flex justify-content--end'>
					<img src='/images/partner-layer-2-logo.png' alt='logo' />
				</div>
			</div>
			<div className='content flex justify-content--between align-items--center width--full'>
				<div className='title-wrapper'>
					<p className='font-size--14 flex align-items--center'>
						<span className='square mr--10' />
						Trusted by
					</p>
					<h1 className='section-title  font--bold'>
						Our <span className='gradient-text'>Strategic</span> Partners
					</h1>
				</div>
				<p className='desc font-size--32 font--bold'>Immersive In-Game Ads & Product Placement</p>
				<p className='desc font-size--32 font--bold'>
					Layer 1 Blockchain with zero gas transactions and enhanced security
				</p>
			</div>
		</section>
	);
};
