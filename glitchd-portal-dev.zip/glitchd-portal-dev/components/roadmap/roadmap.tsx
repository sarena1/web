'use client';

import { useScroll } from 'framer-motion';
import { Explore } from '../explore/explore';
import './roadmap.scss';
import { useRef } from 'react';

export const Roadmap = () => {
	const sectionRef = useRef(null);
	const { scrollYProgress } = useScroll({ container: sectionRef });

	return (
		<section ref={sectionRef} className='roadmap position--relative'>
			<h1 className='section-title text--center'>Roadmap</h1>
			<div className='vertical-line' />
			<div className='content  mt--132 flex justify-content--center flex--column align-items--center'>
				<div className='ellipse1' />
				<h2 className='mt--n-35'>Q1 2024</h2>
				<p className='width--164 text--center font-size--18 line-height--23 mt--24 ls--1'>
					Release of GlitchD Public Testnet
				</p>
				<div className='vertical-line2' />

				<div className='ellipse-too-large flex align-items--center justify-content--center'>
					<div className='ellipse-large flex align-items--center justify-content--center'>
						<div className='ellipse-medium flex align-items--center justify-content--center'>
							<div className='ellipse-small' />
						</div>
					</div>
				</div>
				<div className='vertical-line3' />

				<div className='ellipse1 mt--70' />
				<h2 className='mt--n-35'>Q2 2024</h2>
				<p className='width--229 text--center font-size--18 line-height--23 mt--24 ls--1'>
					Launch of GlitchD Data Availability Network
				</p>
				<div className='vertical-line4' />

				<div className='ellipse1 mt--70' />
				<h2 className='mt--n-35'>Q3 2024</h2>
				<p className='width--229 text--center font-size--18 line-height--23 mt--24 ls--1'>
					Introduction of GlitchD Chain Development Kit (CDK)
				</p>
				<div className='vertical-line5' />
				<div className='ellipse1 mt--70' />
				<h2 className='mt--n-35'>Q4 2024</h2>
				<p className='width--229 text--center font-size--18 line-height--23 mt--24 ls--1 mb--150'>
					Deployment of Initial L1 Zone of App chains with Shared Bridge
				</p>
			</div>
			<Explore
				title='Explore'
				heading='our detailed roadmap and future developments'
				buttonTitle='Explore Roadmap'
			/>
		</section>
	);
};
