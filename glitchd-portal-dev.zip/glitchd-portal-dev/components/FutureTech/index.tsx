import './style.scss';

export const FutureTech = () => {
	return (
		<section className='future-tech flex align-items--center justify-content--center'>
			<div className='content '>
				<p className='font-size--14 flex align-items--center justify-content--center mb--54'>
					<span className='square mr--10' />
					Solutions
				</p>
				<h1 className='section-title big font--bold text--center'>
					Embrace the <span className='gradient-text secondary'>Future</span> of ZK Technology
				</h1>
				<p className='text--center font-size--32  mt--30'>
					Our advanced ZK-EVM solutions deliver unmatched scalability, security, and interoperability.{' '}
				</p>
			</div>
		</section>
	);
};
