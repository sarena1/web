'use client';

import { FC } from 'react';

import './card.scss';

interface IProps {
	graphic: string;
	title: string;
	desc: string;
	steps: { active: string; stepNumber: string };
	// handleCardChange?: () => void;
}

export const Card: FC<IProps> = ({ desc, graphic, title, steps }) => {
	return (
		<div className='card'>
			<div className='graphic-section position--relative'>
				<p className='step position--absolute font-size--24'>
					<span className='active'>{steps.active}</span>&nbsp;/&nbsp;
					<span className='font-size--24'>{steps.stepNumber}</span>
				</p>
				<img src={graphic} alt='card-graphic' />
			</div>
			<div className='card-border' />
			<div className='content'>
				<h3 className='font-size--34 font--bold line-height--35'>{title}</h3>
				<p className='font-size--18 mt--16 line-height--23'>{desc}</p>
			</div>
		</div>
	);
};
