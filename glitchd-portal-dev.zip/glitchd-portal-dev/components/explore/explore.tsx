import { DisCordIcon, RectangleIcon, TwitterIcon } from '@/public/icons/icon';
import './explore.scss';

export interface IProps {
	title: string;
	heading: string;
	buttonTitle: string;
}

export const Explore: React.FC<IProps> = ({ title, heading, buttonTitle }) => {
	return (
		<section className='explore width--full'>
			<div className='content'>
				<div className='marque flex'>
					<div className='flex marquee-1'>
						{[1, 2, 3, 4, 5].map((item) => (
							<div key={item} className='title flex align-items--center justify-content--center mb--80'>
								<h1 className='font-size--140 line-height--147'>{title}</h1>
								<RectangleIcon className='rectangle-icon ml--40 mr--40' />
							</div>
						))}
					</div>
					<div className='flex marquee-2'>
						{[1, 2, 3, 4, 5].map((item) => (
							<div key={item} className='title flex align-items--center justify-content--center mb--80'>
								<h1 className='font-size--140 line-height--147'>{title}</h1>
								<RectangleIcon className='rectangle-icon ml--40 mr--40' />
							</div>
						))}
					</div>
					<div className='flex marquee-3'>
						{[1, 2, 3, 4, 5].map((item) => (
							<div key={item} className='title flex align-items--center justify-content--center mb--80'>
								<h1 className='font-size--140 line-height--147'>{title}</h1>
								<RectangleIcon className='rectangle-icon ml--40 mr--40' />
							</div>
						))}
					</div>
				</div>
				<h1 className='future-heading text--center'>{heading}</h1>
				<div className='icons flex align-items--center justify-content--between'>
					<div className='twitter-icon flex justify-content--center align-items--center'>
						<TwitterIcon />
					</div>
					<button className='explore-button'>{buttonTitle}</button>
					<div className='discord-icon flex justify-content--center align-items--center ml--5'>
						<DisCordIcon />
					</div>
				</div>
			</div>
		</section>
	);
};
