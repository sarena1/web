import Link from 'next/link';
import './style.scss';
import { DisCordIcon, TwitterIcon } from '@/public/icons/icon';

export const FooterSection = () => {
	return (
		<>
			<section className='footer-section '>
				<div className='icon-group'>
					<div className='icon'>
						<TwitterIcon className='twitter' />
					</div>
					<div className='icon'>
						<DisCordIcon className='discord' />
					</div>
				</div>
				<h1 className='section-title footer-heading text--center width--full'>
					Journey into the interconnected future with GlitchD Labs’ ZK-EVM technology
				</h1>

				<button className='footer-mobile-btn'>Build on GlitchD</button>

				<div className='footer-link position--absolute width--full links flex justify-content--between'>
					<div className='flex'>
						<p>©{new Date().getFullYear()} GlitchD</p>
						<Link className='text--secondary ml--30' href='#'>
							Terms of Service
						</Link>
					</div>
					<div className='flex justify-content--center'>
						<div className='company-policy flex justify-content--center align-items--center'>
							<Link className='text--secondary font--medium font-size--24' href='#'>
								About
							</Link>
							<Link className='text--secondary font--medium font-size--24 ml--30' href='#'>
								Technology
							</Link>
							<Link className='text--secondary font--medium font-size--24 ml--30' href='#'>
								Ecosystem
							</Link>
							<Link className='text--secondary font--medium font-size--24 ml--30' href='#'>
								Dev Docs
							</Link>
						</div>
					</div>
					<div className='flex'>
						<Link className='text--secondary' href='#'>
							Cookie Policy
						</Link>
						<Link className='text--secondary ml--30' href='#'>
							Terms of Service
						</Link>
					</div>
				</div>
			</section>
		</>
	);
};
