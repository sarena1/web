import Transition from '@/app/animations';

export const HeroLayer2 = () => {
	return (
		<Transition>
			<section className='hero-section layer2 flex  justify-content--center'>
				<div className='content '>
					<h1 className='section-title big font--bold text--center'>
						Unmatched <span className='gradient-text secondary'>Security</span> with GlitchD Labs{' '}
					</h1>
					<p className='text--center font-size--32 font--bold mt--30'>
						Superior ZK-EVM technology solving real-world problems.
					</p>
				</div>
			</section>
		</Transition>
	);
};
