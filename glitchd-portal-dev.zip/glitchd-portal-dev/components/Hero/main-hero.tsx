'use client';

import { Hero } from '@/components/Hero/hero';
//@ts-ignore
import { Header } from '../Header';
import './hero.scss';

export default function MainHeroPage() {
	return (
		<>
			<div className='layers-outer'>
				<Header isButtonEnabled={false} />
				<Hero />
			</div>
		</>
	);
}
