import Transition, { TransitionX } from '@/app/animations';
import { FC, MutableRefObject, useCallback, useEffect, useRef, useState } from 'react';
import { Partners } from '../Partners/partners';
import { useWindowLayout } from '../hooks/windo-layout';
import Image from 'next/image';

let scrollLoading = false;

export const Hero = () => {
	const [currentAnimation, setCurrentAnimation] = useState(0);
	const ref = useRef(null);
	const containerRef = useRef(null);

	const handleScroll = useCallback(
		(window: any) => {
			if (typeof window !== 'undefined' && window.deltaY >= 0) {
				if (!scrollLoading) {
					scrollLoading = true;
					setCurrentAnimation((prev) =>
						prev === 0 ? 1 : prev === 1 ? 2 : prev === 2 ? 3 : prev === 3 ? 4 : 4
					);
					setTimeout(() => {
						if (currentAnimation === 3) {
							// where animation ends
							document.body.style.overflowX = 'hidden';
							document.body.style.overflowY = 'unset';
						}
						scrollLoading = false;
					}, 800);
				}
			} else {
				if (!scrollLoading) {
					scrollLoading = true;
					setCurrentAnimation((prev) =>
						prev === 4 ? 3 : prev === 3 ? 2 : prev === 2 ? 1 : prev === 1 ? 0 : 0
					);
					setTimeout(() => {
						// if (currentAnimation === 1) {
						// 	// where animation ends
						// 	document.body.style.overflow = 'unset';
						// }
						scrollLoading = false;
					}, 800);
				}
			}
		},
		[currentAnimation]
	);

	useEffect(() => {
		const container: any = containerRef.current;
		container?.addEventListener('wheel', handleScroll);
		return () => {
			container?.removeEventListener('wheel', handleScroll);
		};
	}, [currentAnimation, handleScroll]);

	useEffect(() => {
		const observer = new IntersectionObserver((entries, { thresholds = 1 }) => {
			entries.forEach((entry) => {
				if (entry.isIntersecting) {
					if (typeof window !== 'undefined') {
						(containerRef.current as any)?.scrollIntoView({
							behavior: 'smooth',
							block: 'start',
							inline: 'nearest'
						});
						document.body.style.overflow = 'hidden';
					}
				}
			});
		});

		if (ref.current) {
			observer.observe(ref.current);
		}

		// return () => {
		// 	if (ref.current) {
		// 		observer.unobserve(ref.current);
		// 	}
		// };
	}, []);

	return (
		<>
			{currentAnimation <= 2 && (
				<Transition>
					<section
						ref={containerRef}
						className={`hero-section layer${currentAnimation} ${currentAnimation <= 2 ? 'flex' : ''}  justify-content--center position--relative`}
					>
						<HeroLayers ref={ref} currentAnimation={currentAnimation} />
						<div style={{ position: 'absolute', bottom: 0, width: '100%' }} ref={ref} />
					</section>
				</Transition>
			)}
			{currentAnimation > 2 && (
				<Transition>
					<section
						ref={containerRef}
						className={`hero-section layer${currentAnimation} ${currentAnimation <= 2 ? 'flex' : ''}  justify-content--center`}
					>
						<PartnerLayers ref={ref} currentAnimation={currentAnimation} />
						<div style={{ position: 'absolute', bottom: 0, width: '100%' }} ref={ref} />
					</section>
				</Transition>
			)}
		</>
	);
};

interface IProps {
	currentAnimation: number;
	ref?: MutableRefObject<null>;
}

const HeroLayers: FC<IProps> = ({ currentAnimation, ref }) => {
	const { width } = useWindowLayout();
	return (
		<>
			<div
				style={{ width: Math.floor((width * 48) / 100), height: Math.floor((width * 48) / 100) }}
				className={`circle position--absolute anime-${currentAnimation}`}
			>
				<img src='/images/light.png' className='position--absolute circular-light' alt='orbit-light' />
			</div>
			<div className={`circle-small position--absolute anime-${currentAnimation}-small`} />
			<div className={`circle-medium position--absolute anime-${currentAnimation}-medium`} />
			{currentAnimation === 3 && (
				<TransitionX xPosition='-40%'>
					<div className='logo-wrapper flex width--full justify-content--end'>
						<img className='logo' src='/images/partner-layer-1-logo.png' alt='logo' />
					</div>
				</TransitionX>
			)}

			<div className='content '>
				{
					<Transition>
						<h1 className='section-title big font--bold text--center'>
							Unmatched{' '}
							<span className='glitch-title'>
								{currentAnimation === 0 && <span className='gradient-text'>Scalability</span>}
								{currentAnimation === 1 && (
									<span className={`glitch-heading-${currentAnimation} gradient-text secondary`}>
										Security
									</span>
								)}
								{currentAnimation === 2 && (
									<span className={`glitch-heading-${currentAnimation} gradient-text tertery`}>
										Efficiency
									</span>
								)}
							</span>{' '}
							with GlitchD Labs{' '}
						</h1>
					</Transition>
				}
				{/* {currentAnimation === 1 && (
					<Transition>
						<h1 className='section-title big font--bold text--center'>
							Unmatched <span className='gradient-text secondary'>Security</span> with GlitchD Labs{' '}
						</h1>
					</Transition>
				)}
				{currentAnimation === 2 && (
					<Transition>
						<h1 className='section-title big font--bold text--center'>
							Unmatched <span className='gradient-text tertery'>Efficiency</span> with GlitchD Labs
						</h1>
					</Transition>
				)}
				{currentAnimation <= 2 && (
					<p className='text--center font-size--32 font--bold mt--30'>
						Superior ZK-EVM technology solving real-world problems.
					</p>
				)} */}
			</div>
			{currentAnimation === 3 && (
				<Transition>
					<div className='content-partner flex justify-content--between align-items--center width--full'>
						<div className='title-wrapper'>
							<p className='font-size--14 flex align-items--center'>
								<span className='square mr--10' />
								Trusted by
							</p>
							<h1 className='section-title  font--bold'>
								Our <span className='gradient-text'>Strategic</span> Partners
							</h1>
						</div>
						<p className='desc font-size--32 font--bold'>Immersive In-Game Ads & Product Placement</p>
					</div>
				</Transition>
			)}
		</>
	);
};

const PartnerLayers: FC<IProps> = ({ currentAnimation, ref }) => {
	const { width } = useWindowLayout();

	return (
		<>
			<div className='partners-layers--hide'>
				<div
					style={{ width: Math.floor((width * 48) / 100), height: Math.floor((width * 48) / 100) }}
					className={`circle position--absolute anime-${currentAnimation}`}
				>
					{' '}
					<img src='/images/light.png' className='position--absolute circular-light' alt='orbit-light' />
				</div>
				<div className={`circle-small position--absolute anime-${currentAnimation}-small`} />
				<div className={`circle-medium position--absolute anime-${currentAnimation}-medium`} />
				<Partners currentAnimation={currentAnimation} />
			</div>
			<div className='content-partner-mobile'>
				<Transition>
					<div className='content-partner '>
						<div className='title-wrapper'>
							<p className='font-size--14 flex align-items--center'>
								<span className='square mr--10' />
								Trusted by
							</p>
							<h1 className='section-title  font--bold'>
								Our{' '}
								<span className='gradient-text'>
									Strategic <br />
								</span>{' '}
								Partners
							</h1>
						</div>
						<div className='brand-content'>
							<p className='brandNumber'>
								01<span className='blurText'>/02</span>
							</p>
							<Image
								className='logos'
								src='/images/partner-layer-1-logo.png'
								alt='logo'
								width={186}
								height={197}
							/>
						</div>
						<p className='partner-desc'>
							Immersive In-Game <br /> Ads and Product <br /> Placement
						</p>
						<div className='brand-content'>
							<p className='brandNumber'>
								02<span className='blurText'>/02</span>
							</p>
							<Image
								className='logos'
								src='/images/partner-layer-2-logo.png'
								alt='logo'
								width={186}
								height={197}
							/>
						</div>
						<p className='partner-desc'>
							Layer 1 Blockchain <br /> with zero gas transactions <br /> and enhanced security
						</p>
					</div>
				</Transition>
			</div>
		</>
	);
};
