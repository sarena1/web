import Transition from '@/app/animations';

export const HeroLayer3 = () => {
	return (
		<Transition>
			<section className='hero-section layer3 flex  justify-content--center'>
				<div className='content'>
					<h1 className='section-title big font--bold text--center'>
						Unmatched <span className='gradient-text tertery'>Efficiency</span> with GlitchD Labs
					</h1>
					<p className='text--center font-size--32 font--bold mt--30'>
						Superior ZK-EVM technology solving real-world problems.
					</p>
				</div>
			</section>
		</Transition>
	);
};
