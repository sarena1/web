'use client';

import { Card } from '../Card/card';
import './technical-advantages.scss';

import { useEffect, useRef, useState } from 'react';

let scrollLoading = false;
let isScrollLocked = false;
export const TechnicalAdvantages = () => {
	const [rotate, setRotate] = useState(0); // Initial rotation
	const ref = useRef(null);
	const containerRef = useRef(null);

	const handleScroll = (window: any) => {
		if (!scrollLoading && isScrollLocked) {
			if (window.deltaY >= 0) {
				setRotate((prev) => (prev === 0 ? 11 : prev === 11 ? 22 : 22));
				scrollLoading = true;
				setTimeout(() => {
					if (rotate === 11) {
						// where animation ends
						document.body.style.overflowX = 'hidden';
						document.body.style.overflowY = 'unset';
						isScrollLocked = false;
					}
					scrollLoading = false;
				}, 800);
			} else {
				scrollLoading = true;
				setRotate((prev) => (prev === 22 ? 11 : prev === 11 ? 0 : 0));
				setTimeout(() => {
					if (rotate === 11) {
						// where animation ends
						document.body.style.overflowX = 'hidden';
						document.body.style.overflowY = 'unset';
						isScrollLocked = false;
					}
					scrollLoading = false;
				}, 800);
			}
		}
	};

	useEffect(() => {
		const container: any = containerRef.current;

		container?.addEventListener('wheel', handleScroll);

		return () => {
			container?.removeEventListener('wheel', handleScroll);
		};
	}, [rotate]);

	useEffect(() => {
		const observer = new IntersectionObserver((entries, { thresholds = 1 }) => {
			entries.forEach((entry) => {
				if (entry.isIntersecting) {
					if (typeof window !== 'undefined') {
						(containerRef.current as any)?.scrollIntoView({
							behavior: 'smooth',
							block: 'start',
							inline: 'nearest'
						});
						document.body.style.overflow = 'hidden';
						isScrollLocked = true;
					}
				}
			});
		});

		if (ref.current) {
			observer.observe(ref.current);
		}

		// return () => {
		// 	if (ref.current) {
		// 		observer.unobserve(ref.current);
		// 	}
		// };
	}, []);

	return (
		<section ref={containerRef} className='tech-advantage'>
			<h1 className='section-title text--center'>Technical Advantages</h1>

			<div
				style={{
					position: 'absolute',
					width: '8000px',
					height: '8000px',
					top: '67%',
					borderRadius: '50%',
					border: '2px solid transparent',
					transition: 'all 0.5s linear',
					transform: `rotate(-${rotate}deg)`
				}}
				className='card-section'
			>
				<div className='card1'>
					<Card
						graphic='/images/tech-card-1.png'
						desc='Our ZK-EVM chain supports a multi-chain ecosystem with advanced parallel processing, ensuring applications scale smoothly without compromising speed or competency.'
						title='Ultra-High Throughput'
						steps={{ active: '01', stepNumber: '03' }}
					/>
				</div>
				<div className='card2'>
					<Card
						graphic='/images/tech-card-2.png'
						desc={`GlitchD's ZK-Stack includes highly optimized modules, offering flexibility and enhancing operational effectiveness for custom implementations.`}
						title='Customizable Solutions'
						steps={{ active: '02', stepNumber: '03' }}
					/>
				</div>
				<div className='card3'>
					<Card
						graphic='/images/tech-card-3.png'
						desc='With our Data Stream Integrity protocol, bridges and IBC technology, we ensure coherent interoperability, enabling unprecedented cross-chain communication and asset transfers.'
						title='Seamless Integration'
						steps={{ active: '03', stepNumber: '03' }}
					/>
				</div>
			</div>

			<div className='card-section--mobile mt--30'>
				<div className='tech-card'>
					<Card
						graphic='/images/tech-card-1.png'
						desc='Our ZK-EVM chain supports a multi-chain ecosystem with advanced parallel processing, ensuring applications scale smoothly without compromising speed or competency.'
						title='Ultra-High Throughput'
						steps={{ active: '01', stepNumber: '03' }}
						// handleCardChange={() => handleClickCard(0)}
					/>
				</div>
				<div className='tech-card'>
					<Card
						graphic='/images/tech-card-2.png'
						desc={`GlitchD's ZK-Stack includes highly optimized modules, offering flexibility and enhancing operational effectiveness for custom implementations.`}
						title='Customizable Solutions'
						steps={{ active: '02', stepNumber: '03' }}
						// handleCardChange={() => handleClickCard(1)}
					/>
				</div>
				<div className='tech-card'>
					<Card
						graphic='/images/tech-card-3.png'
						desc='With our Data Stream Integrity protocol, bridges and IBC technology, we ensure coherent interoperability, enabling unprecedented cross-chain communication and asset transfers.'
						title='Seamless Integration'
						steps={{ active: '03', stepNumber: '03' }}
						// handleCardChange={() => handleClickCard(2)}
					/>
				</div>
			</div>
			<div style={{ position: 'absolute', bottom: 0, width: '100%' }} ref={ref} />
		</section>
	);
};
