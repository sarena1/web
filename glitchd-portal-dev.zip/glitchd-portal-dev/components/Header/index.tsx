import React, { FC, useState } from 'react';
import {
	DisCordIcon,
	HamburgerMenu,
	HamburgerMenuClose,
	Logo,
	ResponsiveLogo,
	RightAngleIcon,
	TwitterIcon
} from '@/public/icons/icon';
import './header.scss';
import Link from 'next/link';

interface IProps {
	isButtonEnabled: boolean;
}

export const Header: FC<IProps> = ({ isButtonEnabled }) => {
	const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

	const toggleMobileMenu = () => {
		setIsMobileMenuOpen((prevState) => !prevState);
	};

	return (
		<>
			{!isMobileMenuOpen && (
				<header className='flex justify-content--between width--full'>
					<div className='logo'>
						<Logo />
					</div>
					<div className='responsiveLogo'>
						<ResponsiveLogo />
					</div>
					<div className='icons flex'>
						<div className='icon flex justify-content--center align-items--center'>
							<TwitterIcon />
						</div>
						<div className='icon flex justify-content--center align-items--center ml--5'>
							<DisCordIcon />
						</div>
					</div>
					<div className='hamburger-menu' onClick={toggleMobileMenu}>
						<HamburgerMenu />
					</div>
					<div className='text'>
						{!isButtonEnabled && (
							<>
								<p className='font-size--22'>
									Our technology is designed to solve any challenge across any industry
								</p>
								<p className='font-size--24 font--medium mt--16 text--right flex align-items--center justify-content--end'>
									Unlock Innovations
									<span className='icon width--50'>
										<RightAngleIcon />
									</span>
								</p>
							</>
						)}
						{isButtonEnabled && <button className='btn primary'>Build on GlitchD</button>}
					</div>
				</header>
			)}

			{isMobileMenuOpen && (
				<div className='mobile-menu'>
					<div className='mobile-menu--header'>
						<div className='mobile-logo'>
							<Logo />
						</div>
						<div className='hamburger-menu' onClick={toggleMobileMenu}>
							<HamburgerMenuClose />
						</div>
					</div>
					<div className='mobile-content'>
						<Link href='/'>Home</Link>
						<Link href='#'>About</Link>
						<Link href='#'>Technology</Link>
						<Link href='#'>Ecosystem</Link>
						<Link href='#'>Dev Docs</Link>
					</div>
					<div className='btn-group'>
						<button className='mobile-btn'>Unlock Innovations</button>
						<button className='mobile-btn dark'>Build on GlitchD</button>
					</div>
				</div>
			)}
		</>
	);
};

export const FooterSectionHeader = () => {
	return (
		<header className='flex justify-content--between width--full'>
			<div className='icons'>
				<div className='icon flex justify-content--center align-items--center'>
					<TwitterIcon />
				</div>
			</div>
			<div className='logo'>
				<Logo />
			</div>
			<div className='icons'>
				<div className='icon flex justify-content--center align-items--center ml--5'>
					<DisCordIcon />
				</div>
			</div>
		</header>
	);
};
