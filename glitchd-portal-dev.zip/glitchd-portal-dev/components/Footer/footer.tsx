import Link from 'next/link';

import './footer.scss';

export const Footer = () => {
	return (
		<footer className='flex justify-content--around align-items--center'>
			<Link href='#about'>About</Link>
			<Link href='#technology'>Technology</Link>
			<Link href='#ecosystem'>Ecosystem</Link>
			<Link href='#docs'>Dev Docs</Link>
		</footer>
	);
};
