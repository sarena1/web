'use client';

import { useEffect, useState } from 'react';

export const useWindowLayout = () => {
	const [width, setWidth] = useState(typeof window !== 'undefined' ? window.innerWidth : 1920);
	const [height, setHeight] = useState(typeof window !== 'undefined' ? window.innerHeight : 1920);

	useEffect(() => {
		window.addEventListener('resize', () => {
			if (typeof window !== 'undefined') {
				setWidth(window.innerWidth);
				setHeight(window.innerHeight);
			}
		});
		return () => {
			window.removeEventListener('resize', () => {
				if (typeof window !== 'undefined') {
					setWidth(window.innerWidth);
					setHeight(window.innerHeight);
				}
			});
		};
	}, []);

	return { width, height };
};
