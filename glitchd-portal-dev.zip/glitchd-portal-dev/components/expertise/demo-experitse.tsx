'use client';

import { Expertise } from '.';
import './style.scss';

export const DemoExpertise = () => {
	// const [size, setSize] = useState(1000); // Initial size
	// const [boxShadow, setBoxShadow] = useState(false); // Box-shadow flag
	// const [scrollLocked, setScrollLocked] = useState(false); // Scroll lock flag
	// const [topPosition, setTopPosition] = useState(typeof window !== 'undefined' ? window.innerHeight * 0.5 : 0); // Vertical position of the circle in pixels
	// const [lastTopPositionPx, setLastTopPositionPx] = useState(
	// 	typeof window !== 'undefined' ? window.innerHeight * 0.5 : 0
	// ); // Last top position in pixels when size > 4px

	// // const containerRef = useRef(null);
	// // const ref = useRef(null);

	// // const handleInternalScroll = () => {
	// // 	if (scrollLocked) {
	// // 		const container: any = containerRef.current;
	// // 		const scrollY = container.scrollTop;

	// // 		// Shrink the circle size down to 100px while locked
	// // 		const newSize = Math.max(100, 1000 - scrollY);
	// // 		setSize(newSize);

	// // 		if (newSize === 100) {
	// // 			setScrollLocked(false); // Unlock scrolling when size reaches 100px
	// // 			document.body.style.overflow = ''; // Re-enable body scrolling
	// // 			container.style.overflow = 'hidden'; // Disable internal container scrolling
	// // 		}
	// // 	}
	// // };

	// // const handleWindowScroll = () => {
	// // 	const container: any = containerRef.current;
	// // 	if (!container) return;
	// // 	const scrollY = typeof window !== 'undefined' ? window.scrollY : 0;
	// // 	const maxTopOffsetPx = 100; // Maximum top offset in pixels when the size is 4px

	// // 	// Continue shrinking the circle from 100px to 4px as it moves downwards
	// // 	const newSize = Math.max(4, 100 - scrollY);
	// // 	setSize(newSize);

	// // 	if (newSize > 4) {
	// // 		// Update top position and last top position in pixels when size is greater than 4px
	// // 		const newTopPositionPx = lastTopPositionPx + scrollY * 0.1;
	// // 		setTopPosition(newTopPositionPx);
	// // 		setLastTopPositionPx(newTopPositionPx);
	// // 	} else {
	// // 		// When the size is 4px, limit the top position to 100px from the last position
	// // 		const limitedTopPx = Math.min(lastTopPositionPx + maxTopOffsetPx, topPosition + scrollY * 0.1);
	// // 		setTopPosition(limitedTopPx);
	// // 		setBoxShadow(true); // Apply box-shadow at size 4px
	// // 	}

	// // 	if (newSize >= 100) {
	// // 		// const scrollY = container.scrollTop;
	// // 		setScrollLocked(true); // Lock scrolling when size reaches more than 100px
	// // 		if (typeof window !== 'undefined') {
	// // 			document.body.style.overflow = 'hidden'; // disable body scrolling
	// // 		}
	// // 		container.style.overflow = 'auto'; // Enable internal container scrolling
	// // 		setBoxShadow(false); // Remove box-shadow at size 4px
	// // 	}
	// // };

	// // useEffect(() => {
	// // 	// Initialize the top position in pixels to 50% of the viewport height
	// // 	const container: any = containerRef.current;
	// // 	const initialTopPositionPx = typeof window !== 'undefined' ? window.innerHeight * 0.5 : 0;
	// // 	setTopPosition(initialTopPositionPx);
	// // 	setLastTopPositionPx(initialTopPositionPx);

	// // 	// Lock scrolling initially

	// // 	// Attach the scroll listener to the container or window based on scroll lock state
	// // 	if (scrollLocked && container) {
	// // 		container.addEventListener('scroll', handleInternalScroll, { passive: false });
	// // 	} else {
	// // 		if (typeof window !== 'undefined') {
	// // 			window.addEventListener('scroll', handleWindowScroll, { passive: false });
	// // 		}
	// // 	}

	// // 	// Cleanup
	// // 	return () => {
	// // 		if (scrollLocked && container) {
	// // 			container?.removeEventListener('scroll', handleInternalScroll);
	// // 		}
	// // 		if (typeof window !== 'undefined') {
	// // 			window.removeEventListener('scroll', handleWindowScroll);
	// // 			document.body.style.overflowX = 'hidden'; // Re-enable body scrolling on component unmount
	// // 			document.body.style.overflowY = 'unset'; // Re-enable body scrolling on component unmount
	// // 		}
	// // 	};
	// // }, [scrollLocked]);

	// // useEffect(() => {
	// // 	const observer = new IntersectionObserver((entries, { thresholds = 1 }) => {
	// // 		entries.forEach((entry) => {
	// // 			if (entry.isIntersecting) {
	// // 				if (typeof window !== 'undefined') {
	// // 					console.log((containerRef?.current as any).offsetTop, window.screenTop);

	// // 					(containerRef.current as any)?.scrollIntoView({
	// // 						behavior: 'smooth',
	// // 						block: 'start',
	// // 						inline: 'nearest'
	// // 					});
	// // 					document.body.style.overflow = 'hidden';
	// // 					setScrollLocked(true);
	// // 				}
	// // 			}
	// // 		});
	// // 	});

	// // 	setTimeout(() => {
	// // 		if (ref.current) {
	// // 			observer.observe(ref.current);
	// // 		}
	// // 	}, 200);

	// // 	// return () => {
	// // 	// 	if (ref.current) {
	// // 	// 		observer.unobserve(ref.current);
	// // 	// 	}
	// // 	// };
	// // }, []);

	return (
		<>
			<Expertise />
		</>
	);
};
