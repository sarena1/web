'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import './style.scss';

let scrollLoading = false;
let isScrollLocked = false;

const rotateAnimationText = [
	'We use zero-knowledge (ZK) technology to solve real-world problems across various sectors, from financial services to gaming',
	'Our ZK proofs deliver solutions that protect sensitive data while maintaining high performance and scalability',
	'With our Data Stream Integrity Protocol and Hyperchains leveraging IBC technology, we’re fostering an interconnected future that is not limited to the traditional blockchain'
];

export const Expertise = () => {
	const ref = useRef(null);
	const scrollRef = useRef(null);
	const [currentAnimation, setCurrentAnimation] = useState(0);
	const [rotateAnimation, setRotateAnimation] = useState(0);
	const [text2Animation, setText2Animation] = useState(0);
	const [text3Animation, setText3Animation] = useState(0);
	const [rotateIndex, setRotateIndex] = useState(0);

	const handleScroll = useCallback(
		(window: any) => {
			if (window.deltaY >= 0) {
				if (!scrollLoading) {
					scrollLoading = true;
					setCurrentAnimation((prev) =>
						prev === 0 ? 1 : prev === 1 ? 2 : prev === 2 ? 3 : prev === 3 ? 4 : prev === 4 ? 5 : 5
					);
					if (currentAnimation > 3) setRotateAnimation((prev) => (prev === 0 ? 1 : prev === 1 ? 2 : 3));
					if (rotateAnimation >= 2) setText2Animation((prev) => (prev === 0 ? 1 : prev === 1 ? 2 : 2));
					if (text2Animation >= 2) setText3Animation((prev) => (prev === 0 ? 1 : prev === 1 ? 2 : 2));
					setTimeout(() => {
						if (text2Animation === 2) {
							// where animation ends
							document.body.style.overflowX = 'hidden';
							document.body.style.overflowY = 'unset';
							isScrollLocked = false;
						}
						scrollLoading = false;
					}, 800);
				}
			}
		},
		[currentAnimation, rotateAnimation, text2Animation]
	);

	useEffect(() => {
		if (typeof window !== 'undefined') {
			(scrollRef?.current as any).addEventListener('wheel', handleScroll);
		}
		return () => {
			(scrollRef?.current as any).removeEventListener('wheel', handleScroll);
		};
	}, [handleScroll]);

	useEffect(() => {
		const observer = new IntersectionObserver((entries, { thresholds = 1 }) => {
			entries.forEach((entry) => {
				if (entry.isIntersecting) {
					if (typeof window !== 'undefined') {
						(scrollRef.current as any)?.scrollIntoView({
							behavior: 'smooth',
							block: 'start',
							inline: 'nearest'
						});
						document.body.style.overflow = 'hidden';
						isScrollLocked = true;
					}
				}
			});
		});

		if (ref.current) {
			observer.observe(ref.current);
		}

		// return () => {
		// 	if (ref.current) {
		// 		observer.unobserve(ref.current);
		// 	}
		// };
	}, []);

	return (
		<section ref={scrollRef} className='expertise flex justify-content--center'>
			{currentAnimation < 4 && (
				<>
					<div className={`circle scale-${currentAnimation}`} />
					<h1
						className={`section-title position--absolute content text--center content-anim-${currentAnimation}`}
					>
						<p className='font-size--14 flex align-items--center justify-content--center'>
							<span className='square mr--10' />
							About
						</p>
						With expertise in ZK-EVM technology and blockchain solutions,{' '}
						<span className='gradient-text expertise'>
							GlitchD Labs is creating an interconnected future
						</span>
						, in a secure and verifiable manner
					</h1>
				</>
			)}
			{currentAnimation >= 4 && (
				<>
					<div
						className='circle-big position--absolute'
						style={{
							width: typeof window !== 'undefined' ? window.innerWidth : 0,
							height: typeof window !== 'undefined' ? window.innerHeight : 0,
							bottom: typeof window !== 'undefined' ? -(window.innerHeight - 200) : 0
						}}
					/>
					<p
						className={`hide-text position--absolute font-size--24 sprite-text sprite-anime-${currentAnimation}`}
					>
						Unmatched <span className='highlighted'>Efficiency</span>
					</p>
					<p
						className={`hide-text position--absolute font-size--24 sprite-text sprite-anime-right-${currentAnimation}`}
					>
						Unmatched <span className='highlighted'>Efficiency</span>
					</p>
					{currentAnimation >= 4 && rotateAnimation <= 2 && (
						<p
							className={`rotate-text animation-${rotateAnimation} font--bold position--absolute font-size--48 text--center`}
						>
							<span className='rotate-title'>
								Unmatched <span className='highlight-yellow'>Efficiency</span>{' '}
							</span>
							<br />
							{rotateAnimationText[0]}
						</p>
					)}
					{rotateAnimation > 1 && text3Animation <= 0 && (
						<p
							className={`rotate-text text-2-animation-${text2Animation} font--bold position--absolute font-size--48 text--center`}
						>
							<span className='rotate-title'>
								Unmatched <span className='highlight-red'>Security</span>{' '}
							</span>
							<br />
							{rotateAnimationText[1]}
						</p>
					)}
					{text2Animation > 1 && (
						<p
							className={`rotate-text text-3-animation-${text3Animation}  font--bold position--absolute font-size--48 text--center`}
						>
							<span className='rotate-title'>
								Unmatched <span className='highlight-blue'>Scalability</span>{' '}
							</span>
							<br />
							{rotateAnimationText[2]}
						</p>
					)}
				</>
			)}
			<div style={{ position: 'absolute', bottom: 0, width: '100%' }} ref={ref} />
		</section>
	);
};
