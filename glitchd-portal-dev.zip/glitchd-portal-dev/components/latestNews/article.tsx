import { RightAngleIcon } from '@/public/icons/icon';
import './latestNews.scss';

interface IProps {
	src: string;
	tag: string;
	date: string;
	title: string;
	className?: string;
}

export const Article: React.FC<IProps> = ({ src, tag, date, title, className = '' }) => {
	return (
		<section className={`article ${className}`}>
			<div className='article-wrapper'>
				<img src={src} className='article-image' alt='Not Found' />
				<div className='article-main'>
					<div className='flex align-items--center justify-content--between mb--36'>
						<div className='flex align-items--center justify-content--center'>
							<div className='tag-box mr--12' />
							<p className='font-size--14 line-height--21 font--regular text--neutral-500'>{tag}</p>
						</div>
						<p className='font-size--14 line-height--21 font--regular text--neutral-500'>{date}</p>
					</div>
					<h2 className='mb--36'>{title}</h2>
					<div className='flex align-items--center justify-content--end'>
						<div className='flex align-items--center width--full justify-content--end'>
							<h3 className='article-text'>Full Article</h3>
							<RightAngleIcon className='width--50 right-arrow' />
						</div>
					</div>
				</div>
			</div>
		</section>
	);
};
