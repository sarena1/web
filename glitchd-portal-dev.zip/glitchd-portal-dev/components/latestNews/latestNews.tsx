import { Article } from './article';
import './latestNews.scss';

export const LatestNews = () => {
	return (
		<section className='latest-news'>
			<div className='flex align-items--center justify-content--center'>
				<div className='blog-box mr--12' />
				<p className='font-size--14 line-height--21 font--regular '>Blog</p>
			</div>
			<h1 className='latest-news-heading section-title text--center'>
				<span className='news-heading'>Stay tuned</span> for our latest news
			</h1>
			<div className='news-cards flex align-items--center justify-content--center'>
				<Article
					tag='TAG'
					src='/images/solution-card-1.png'
					date='Date'
					title='Introducing GlitchD Appchains: The Future of Blockchain Scalability'
					className='mr--20'
				/>
				<Article
					tag='TAG'
					src='/images/solution-card-1.png'
					date='Date'
					title='How Data Availability Networks Enhance Blockchain Security'
					className='mr--20'
				/>
				<Article
					tag='TAG'
					src='/images/solution-card-1.png'
					date='Date'
					title='Exploring the Applications of GlitchD CDK in Financial Services'
				/>
			</div>
		</section>
	);
};
