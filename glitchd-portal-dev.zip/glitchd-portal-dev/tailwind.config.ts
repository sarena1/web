import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./views/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        "tasa-orbiter-text-bold": "TASAOrbiterTextBold",
        "tasa-orbiter-text-medium": "TASAOrbiterTextMedium",
        "tasa-orbiter-text-regular": "TASAOrbiterTextRegular",
        "tasa-orbiter-text-semi-bold": "TASAOrbiterTextSemiBold",
        "tasa-orbiter-deck-bold": "TASAOrbiterDeckBold",
        "tasa-orbiter-deck-medium": "TASAOrbiterDeckMedium",
        "tasa-orbiter-deck-regular": "TASAOrbiterDeckRegular",
        "tasa-orbiter-deck-semi-bold": "TASAOrbiterDeckSemiBold",
        "tasa-orbiter-display-black": "TASAOrbiterDisplayBlack",
        "tasa-orbiter-display-bold": "TASAOrbiterDisplayBold",
        "tasa-orbiter-display-medium": "TASAOrbiterDisplayMedium",
        "tasa-orbiter-display-regular": "TASAOrbiterDisplayRegular",
        "tasa-orbiter-display-semi-bold": "TASAOrbiterDisplaySemiBold",
      },
      minHeight: {
        "100vhdesk": "calc(100vh - 73px - 20px)",
        "100vhmob": "calc(100dvh - 64px - 8px)"

      }
    },
  },
  plugins: [],
};
export default config;
