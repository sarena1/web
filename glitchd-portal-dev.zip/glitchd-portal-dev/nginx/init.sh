#!/bin/sh

set -xe

# start nginx in background
nginx -g "daemon on;"
# create a certificate
certbot --nginx --non-interactive --agree-tos --keep-until-expiring --email "george@glitchd.network" -d glitchd.network --no-redirect --verbose
# reload nginx
nginx -s quit
nginx -g "daemon off;"
