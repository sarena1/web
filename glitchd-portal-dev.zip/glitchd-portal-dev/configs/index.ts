export const MENU = [];
export const SOCIAL_URL = {
    in: "#",
    x: "https://x.com/GlitchDLabs",
    discord: "https://discord.gg/glitchd",
}